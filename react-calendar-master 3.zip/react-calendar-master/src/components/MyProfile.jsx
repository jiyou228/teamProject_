import styled from "styled-components";
import React from "react";

export default function MyProfile({ displayName }) {
  return (
    <ProfileWrapper>
      <DefaultImg src="./assets/images/user.png" alt="userImage" />
      <UserName>{displayName}</UserName>
    </ProfileWrapper>
  );
}
const DefaultImg = styled.img`
  width: 50px;
  height: 50px;
`;
const UserName = styled.div`
  font-size: 20px;
  margin-left: 15px;
  font-weight: 700;
`;
const ProfileWrapper = styled.div`
  display: flex;
  height: 100%;
  align-items: center;
`;
