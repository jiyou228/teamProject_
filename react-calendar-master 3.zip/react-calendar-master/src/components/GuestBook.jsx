import styled from "styled-components";
import React, { useEffect, useState } from "react";

export default function GuestBook({ userData: { visitMsg, visitUsers } }) {
  const [msgInfo, setMsgInfo] = useState([]);

  useEffect(() => {
    let messages = [];
    if (!!visitMsg) {
      visitMsg.forEach((msg, index) => {
        messages.push({ visitMsg: msg, visitUsers: visitUsers[index] });
      });
      setMsgInfo((prev) => {
        return [...prev, ...messages];
      });
    }
  }, [visitMsg, visitUsers]);
  return (
    <GuestBookWrapper>
      {msgInfo?.map((msg) => {
        return (
          <BodyWrapper>
            <Thumbnail>{msg.visitUsers[0]}</Thumbnail>
            <Message>{msg.visitMsg}</Message>
          </BodyWrapper>
        );
      })}
    </GuestBookWrapper>
  );
}

const BodyWrapper = styled.div`
  display: flex;
  align-items: center;
`;
const Message = styled.p`
  font-size: 15px;
  font-weight: 700;
`;
const GuestBookWrapper = styled.div`
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 20px;
  height: 27vh;
  margin-top: 15px;
  margin-bottom: -65px;
`;

const Thumbnail = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 70%;
  overflow: hidden;
  border: 2px solid grey;
  margin-right: 15px;
  background-color: #e6e4e4;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
`;
