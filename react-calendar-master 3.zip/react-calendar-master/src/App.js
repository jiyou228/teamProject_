import React, { useEffect } from "react";
import { Provider } from "react-redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { createStore, applyMiddleware } from "redux";
import rootReducer from "./store/rootReducer";
import { firestore } from "./firebase";
import Main from "./pages/Main";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
const store = createStore(rootReducer, composeWithDevTools(applyMiddleware()));

function App() {
  useEffect(() => {});
  return (
    <BrowserRouter>
      <Provider store={store}>
        <Routes>
          <Route path="/" element={<Main />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
      </Provider>
    </BrowserRouter>
  );
}

export default App;
