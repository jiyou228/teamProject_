import styled from "styled-components";
import React, { useEffect, useState } from "react";
import { db } from "../firebase";

export default function GuestBook({ displayName, curUser }) {
  const [msgInfo, setMsgInfo] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [isWriteMsg, setIsWriteMsg] = useState(false);
  const onChangeHandler = (e) => {
    setUserInput(e.target.value);
  };
  const onSetMsg = async (e) => {
    if (e.keyCode === 13) {
      const getUser = await db.collection("users").get();

      getUser.forEach((userData) => {
        if (userData.data().displayName === displayName) {
          const updateMsg = async () => {
            await db
              .collection("users")
              .doc(userData.data().uid)
              .update({
                visitMsg: [...userData.data().visitMsg, userInput],
                visitUsers: [...userData.data().visitUsers, curUser],
              });
          };
          updateMsg();
        }
      });
      setUserInput("");
    }
    setIsWriteMsg(!isWriteMsg);
  };
  useEffect(() => {
    let messages = [];
    db.collection("users")
      .get()
      .then((res) => {
        res.forEach((userData) => {
          if (userData.data().displayName === displayName) {
            const visitMsg = userData.data().visitMsg;
            const visitUsers = userData.data().visitUsers;
            visitMsg.forEach((msg, index) => {
              messages.push({ visitMsg: msg, visitUsers: visitUsers[index] });
            });
            setMsgInfo((prev) => {
              return [...messages];
            });
          }
        });
      });
  }, [isWriteMsg]);
  useEffect(() => {
    let messages = [];
    setMsgInfo([]);
    db.collection("users")
      .get()
      .then((res) => {
        res.forEach((userData) => {
          if (userData.data().displayName === displayName) {
            const visitMsg = userData.data().visitMsg;
            const visitUsers = userData.data().visitUsers;
            visitMsg.forEach((msg, index) => {
              messages.push({ visitMsg: msg, visitUsers: visitUsers[index] });
            });
            setMsgInfo((prev) => {
              return [...messages];
            });
          }
        });
      });
  }, [displayName]);
  return (
    <GuestBookWrapper>
      <Messages>
        {msgInfo?.map((msg) => {
          return (
            <BodyWrapper>
              <Thumbnail>{msg.visitUsers[0]}</Thumbnail>
              <Message>{msg.visitMsg}</Message>
            </BodyWrapper>
          );
        })}
      </Messages>
      {curUser === displayName ? (
        ""
      ) : (
        <UserInput
          onKeyDown={onSetMsg}
          onChange={onChangeHandler}
          placeholder="방명록을 남기세요!"
          value={userInput}
        />
      )}
    </GuestBookWrapper>
  );
}

const Messages = styled.div`
  height: 92%;
  overflow: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const UserInput = styled.input`
  border-radius: 10px;
  height: 25px;
  font-size: 17px;
  padding: 2px 10px;
`;

const BodyWrapper = styled.div`
  display: flex;
  align-items: center;
`;
const Message = styled.p`
  font-size: 15px;
  font-weight: 700;
`;
const GuestBookWrapper = styled.div`
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 20px;
  height: 27vh;
  margin-top: 15px;
  margin-bottom: -65px;
`;

const Thumbnail = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 70%;
  overflow: hidden;
  border: 2px solid grey;
  margin-right: 15px;
  background-color: #e6e4e4;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
`;
