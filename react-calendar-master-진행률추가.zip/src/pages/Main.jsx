import React, { useEffect, useState } from "react";
import Calendar from "../components/Calendar";
import TodoList from "../components/TodoList";
import { db } from "../firebase";
import { getAuth, onAuthStateChanged, signOut } from "firebase/auth";
import styled from "styled-components";
import MyProfile from "../components/MyProfile";
import AddFriend from "../components/AddFriend";
import GuestBook from "../components/GuestBook";
import { useNavigate } from "react-router-dom";

export default function Main() {
  const navigate = useNavigate();
  const [curUser, setCurUser] = useState({});
  const [selectedFriend, setSelectedFriend] = useState();

  const logOut = async () => {
    await signOut(getAuth());
    navigate("/login");
  };
  const backToMyProfile = () => {
    setSelectedFriend(null);
  };
  useEffect(() => {
    const setUser = async () => {
      const auth = getAuth();

      onAuthStateChanged(auth, (user) => {
        if (user) {
          db.collection("users")
            .get()
            .then((res) => {
              res.forEach((userData) => {
                if (userData.data().uid === user.uid) {
                  setCurUser((prev) => {
                    return {
                      ...prev,
                      friends: [...userData.data().friends],
                      uid: user.uid,
                      displayName: userData.data().displayName,
                      visitMsg: userData.data().visitMsg,
                      visitUsers: userData.data().visitUsers,
                    };
                  });
                }
              });
            });
        } else {
          navigate("/login");
        }
      });
    };
    setUser();
  }, []);
  return (
    <MainWrapper>
      <AddFriendWrapper>
        <AddFriend userData={curUser} setSelectedFriend={setSelectedFriend} />
        <LogOut onClick={logOut}>로그아웃</LogOut>
      </AddFriendWrapper>
      <BodyWrapper>
        <Container>
          <MyProfileWrapper>
            <MyProfile displayName={selectedFriend ? selectedFriend : curUser.displayName} />
            {selectedFriend && (
              <BackToUser onClick={backToMyProfile}>내 프로필로 돌아가기</BackToUser>
            )}
          </MyProfileWrapper>
          <Calendar />
        </Container>
        <Wrapper>
          <TodoList />
          <GuestBook
            curUser={curUser.displayName}
            displayName={selectedFriend ? selectedFriend : curUser.displayName}
          />
        </Wrapper>
      </BodyWrapper>
    </MainWrapper>
  );
}
const LogOut = styled.div`
  border-radius: 10px;
  border: 2px solid skyblue;
  height: 20px;
  font-size: 13px;
  padding: 2px 5px;
  color: skyblue;
  cursor: pointer;
`;
const BackToUser = styled(LogOut)`
  margin-left: 30px;
`;
const Wrapper = styled.div`
  height: 700px;
`;
const MainWrapper = styled.div`
  margin: auto;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
const Container = styled.div`
  margin: 0 20px 0 50px;
`;
const BodyWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;
const MyProfileWrapper = styled.div`
  height: 80px;
  width: 100%;
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 0 8px 0 rgb(0 0 0 / 4%);
  display: flex;
  align-items: center;
`;
const AddFriendWrapper = styled.div`
  height: 80px;
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 0 8px 0 rgb(0 0 0 / 4%);
  width: 1000px;
  margin-bottom: 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
