import styled from "styled-components";
import React, { useEffect, useState } from "react";
import { GoSearch } from "react-icons/go";
import { db } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function AddFriend({ userData: { uid, friends }, setSelectedFriend }) {
  const [userInput, setUserInput] = useState("");
  // 유저가 검색한 값과 일치하는 유저의 정보를 데이터베이스에서 받아와서 저장해줌
  const [userData, setUserData] = useState({});
  const [errorMsg, setErrorMsg] = useState("");

  // 데이터베이스에서 불러온 로그인된 유저의 친구목록(배열형태로 되어있음)
  const [friendsList, setFriendsList] = useState(friends);
  const navigate = useNavigate();

  const onChangeHandler = (e) => {
    setUserInput(e.target.value);
  };
  const addFriendHandler = async () => {
    // 친구추가 버튼 클릭시 데이터베이스에 userData에 저장된 유저의 정보를 로그인된 유저의 친구로 추가함
    const updateUserInfo = await db
      .collection("users")
      .doc(uid)
      .update({ friends: [...friends, userData.displayName] });
    const setFriends = await db.collection("users").get();
    setFriends.forEach((user) => {
      if (user.data().uid === uid) {
        setFriendsList((prev) => {
          return [...prev, userData.displayName];
        });
      }
    });
    setUserData({});
  };

  // userData라는 상태변수에 유저가 검색한 유저값을 저장함
  useEffect(() => {
    const searchFriend = async () => {
      // 데이터베이스에서 전체유저 정보를 받아옴
      const users = await db.collection("users").get();
      if (userInput === "") {
        setErrorMsg("");
        setUserData({});
      } else {
        // users에는 전체유저정보가 들어있고 로그인된 유저가 검색한 값과 유저데이터중 일치하는 유저가 있으면 userData변수에 저장해줌
        users.forEach((user) => {
          if (userInput.includes(user.data().displayName)) {
            setUserData((prev) => {
              return {
                ...prev,
                uid: user.data().uid,
                displayName: user.data().displayName,
              };
            });
          }
        });
      }
      if (userInput !== "" && !userData.displayName) {
        setErrorMsg("일치하는 유저가 없어요.");
      }
    };
    searchFriend();
  }, [userInput]);
  useEffect(() => {
    setFriendsList(friends);
  }, [friends]);
  return (
    <Wrapper>
      {friendsList?.map((info) => {
        return (
          <div
            style={{ cursor: "pointer" }}
            onClick={() => {
              setSelectedFriend(info);
            }}
          >
            <Thumbnail>{info[0]}</Thumbnail>
            <FullName>{info}</FullName>
          </div>
        );
      })}

      <SearchWrapper>
        <InputWrapper>
          <UserInput onChange={onChangeHandler} placeholder="유저를 검색하세요" />
          <StyledSearch>
            <GoSearch />
          </StyledSearch>
        </InputWrapper>
        <ResultWrapper>
          <Result>{userData.displayName ? userData.displayName : errorMsg}</Result>
          {userData.displayName && <AddButton onClick={addFriendHandler}>친구추가하기</AddButton>}
        </ResultWrapper>
      </SearchWrapper>
    </Wrapper>
  );
}
const FullName = styled.div`
  text-align: center;
  padding-right: 12px;
`;
const InputWrapper = styled.div`
  display: flex;
`;
const SearchWrapper = styled.div``;
const ResultWrapper = styled.div`
  display: flex;
  position: absolute;
  top: 70px;
  font-size: 15px;
`;
const Result = styled.div`
  margin-right: 25px;
  font-size: 13px;
  font-weight: 900;
`;
const AddButton = styled.div`
  border-radius: 10px;
  border: 2px solid skyblue;
  font-size: 13px;
  padding: 2px 5px;
  color: skyblue;
  cursor: pointer;
`;
const StyledSearch = styled.div`
  cursor: pointer;
  margin-right: 10px;
`;
const UserInput = styled.input`
  width: 150px;
  border-width: 0 0 2px 0;
  outline: none;
  font-size: 13px;
  margin-right: 3px;
`;

const Thumbnail = styled.div`
  width: 46px;
  height: 46px;
  border-radius: 70%;
  overflow: hidden;
  border: 2px solid grey;
  margin-right: 10px;
  background-color: #e6e4e4;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
`;
const Wrapper = styled.div`
  height: 100%;
  display: flex;
  align-items: center;
`;
