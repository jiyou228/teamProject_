import styled from "styled-components";
import React, { useEffect, useState } from "react";
import { db } from "../firebase";

export default function GuestBook({ displayName, curUser }) {
  const [msgInfo, setMsgInfo] = useState([]);
  const [userInput, setUserInput] = useState("");

  // 유저가 방명록에 내용을 입력했는지 여부를 판단해주는 상태변수
  const [isWriteMsg, setIsWriteMsg] = useState(false);
  const onChangeHandler = (e) => {
    setUserInput(e.target.value);
  };
  const onSetMsg = async (e) => {
    // keycode 13은 enter키임 즉 엔터를 누르면 방명록이 입력되게 하는 로직
    if (e.keyCode === 13) {
      // 데이터베이스에서 전체 유저를 불러옴
      const getUser = await db.collection("users").get();

      getUser.forEach((userData) => {
        if (userData.data().displayName === displayName) {
          // 친구의 방명록 데이터에 유저가 추가한 방명록 내용을 데이터베이스에 추가
          const updateMsg = async () => {
            await db
              .collection("users")
              .doc(userData.data().uid)
              .update({
                visitMsg: [...userData.data().visitMsg, userInput],
                visitUsers: [...userData.data().visitUsers, curUser],
              });
          };
          updateMsg();
        }
      });
      setUserInput("");
    }
    setIsWriteMsg(!isWriteMsg);
  };

  // isWriteMsg 값이 변경될때마다 이 useEffect가 실행되는데
  // 즉 유저가 값을 입력하고 엔터를 누르면 데이터베이스에 방명록 데이터를 저장해줌
  useEffect(() => {
    let messages = [];
    db.collection("users")
      .get()
      .then((res) => {
        res.forEach((userData) => {
          if (userData.data().displayName === displayName) {
            const visitMsg = userData.data().visitMsg;
            const visitUsers = userData.data().visitUsers;
            visitMsg.forEach((msg, index) => {
              messages.push({ visitMsg: msg, visitUsers: visitUsers[index] });
            });
            setMsgInfo((prev) => {
              return [...messages];
            });
          }
        });
      });
  }, [isWriteMsg]);

  // 보고 있는 페이지의 유저의 방명록 정보를 데이터베이스에서 불러옴
  useEffect(() => {
    let messages = [];
    setMsgInfo([]);
    db.collection("users")
      .get()
      .then((res) => {
        res.forEach((userData) => {
          if (userData.data().displayName === displayName) {
            const visitMsg = userData.data().visitMsg;
            const visitUsers = userData.data().visitUsers;
            visitMsg.forEach((msg, index) => {
              messages.push({ visitMsg: msg, visitUsers: visitUsers[index] });
            });
            setMsgInfo((prev) => {
              return [...messages];
            });
          }
        });
      });
  }, [displayName]);
  return (
    <GuestBookWrapper>
      <Messages>
        {msgInfo?.map((msg) => {
          return (
            <BodyWrapper>
              <Thumbnail>{msg.visitUsers[0]}</Thumbnail>
              <Message>{msg.visitMsg}</Message>
            </BodyWrapper>
          );
        })}
      </Messages>
      {curUser === displayName ? (
        ""
      ) : (
        <UserInput
          onKeyDown={onSetMsg}
          onChange={onChangeHandler}
          placeholder="방명록을 남기세요!"
          value={userInput}
        />
      )}
    </GuestBookWrapper>
  );
}

const Messages = styled.div`
  height: 92%;
  overflow: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const UserInput = styled.input`
  border-radius: 10px;
  height: 25px;
  font-size: 17px;
  padding: 2px 10px;
`;

const BodyWrapper = styled.div`
  display: flex;
  align-items: center;
`;
const Message = styled.p`
  font-size: 15px;
  font-weight: 700;
`;
const GuestBookWrapper = styled.div`
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.04);
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 20px;
  height: 27vh;
  margin-top: 15px;
  margin-bottom: -65px;
`;

const Thumbnail = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 70%;
  overflow: hidden;
  border: 2px solid grey;
  margin-right: 15px;
  background-color: #e6e4e4;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
`;
