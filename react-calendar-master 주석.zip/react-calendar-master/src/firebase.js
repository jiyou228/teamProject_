import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import {
  getAuth,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";

const firebaseConfig = {
  // firebase 설정과 관련된 개인 정보
  apiKey: "AIzaSyC1UqI4clOJNZD14aK2q96lZPTMwV8ySZo",
  authDomain: "todocalendar-b0955.firebaseapp.com",
  projectId: "todocalendar-b0955",
  storageBucket: "todocalendar-b0955.appspot.com",
  messagingSenderId: "958888619024",
  appId: "1:958888619024:web:f581ee3de3ffb67cf36e95",
};

// firebaseConfig 정보로 firebase 시작
const firebaseApp = firebase.initializeApp(firebaseConfig);

// db에 저장되어있는 값을 다룰 때 사용
const db = firebase.firestore();
// 로그인/회원가입 인증 때 사용
const firebaseAuth = getAuth(firebaseApp);

// 필요한 곳에서 사용할 수 있도록 내보내기
export {
  db,
  firebaseAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
};
