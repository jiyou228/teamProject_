/* eslint-disable default-case */
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import React, { useEffect, useState } from "react";
import { firebaseAuth, createUserWithEmailAndPassword } from "../firebase";
import { db } from "../firebase";
// 회원가입 폼 사용자 입력 데이터
function Register() {
  const navigate = useNavigate();

  const [errorMsg, setErrorMsg] = useState(" ");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [registerName, setRegisterName] = useState("");
  const [isFill, setIsFill] = useState(false);

  const handleRegister = async () => {
    try {
      setErrorMsg(" ");
      const createdUser = await createUserWithEmailAndPassword(
        firebaseAuth,
        registerEmail,
        registerPassword
      );
      const userId = createdUser.user.uid;
      const setUser = await db
        .collection("users")
        .doc(userId)
        .set({ displayName: registerName, uid: userId, friends: [], visitMsg: [], visitUsers: [] });

      setRegisterEmail("");
      setRegisterPassword("");
      alert("회원가입이 완료되었습니다!");
      navigate("/login");
    } catch (err) {
      switch (err.code) {
        case "auth/weak-password":
          setErrorMsg("비밀번호는 6자리 이상이어야 합니다");
          break;
        case "auth/invalid-email":
          setErrorMsg("잘못된 이메일 주소입니다");
          break;
        case "auth/email-already-in-use":
          setErrorMsg("이미 가입되어 있는 계정입니다");
          break;
      }
    }
  };
  const handleUserInput = (e, type) => {
    if (type === "id") {
      setRegisterEmail(e.target.value);
    } else if (type === "password") {
      setRegisterPassword(e.target.value);
    } else if (type === "name") {
      setRegisterName(e.target.value);
    }
  };
  useEffect(() => {
    if (!(registerEmail === "" || registerPassword === "" || registerName === "")) {
      setIsFill(true);
    } else {
      setIsFill(false);
    }
  }, [registerEmail, registerPassword, registerName]);

  return (
    <SignUpWrapper>
      <SignUpContainer>
        <Title>Register</Title>
        <SignUpForm>
          <UserInput onChange={(e) => handleUserInput(e, "name")} placeholder="NAME" />
          <Line />
          <UserInput onChange={(e) => handleUserInput(e, "id")} placeholder="EMAIL" />
          <Line />
          <UserInput
            type="password"
            onChange={(e) => handleUserInput(e, "password")}
            placeholder="PASSWORD"
          />
          <Line />
          <ErrorMessage>{errorMsg}</ErrorMessage>
          <SubmitBtn disabled={!isFill} onClick={handleRegister} value={isFill}>
            Register
          </SubmitBtn>
        </SignUpForm>
        <Options>
          <Link>이미 계정이 있으신가요?</Link>
          <Link onClick={() => navigate("/login")}>로그인</Link>
        </Options>
      </SignUpContainer>
    </SignUpWrapper>
  );
}
const ErrorMessage = styled.p`
  color: red;
  font-size: 9px;
  text-align: left;
`;
const Link = styled.a`
  text-decoration: none;
  cursor: pointer;
`;
const Options = styled.div`
  display: flex;
  justify-content: space-evenly;
  width: 70%;
  font-size: 9px;
`;
const Line = styled.div`
  width: 243px;
  height: 1px;
  background-color: black;
  margin-bottom: 15px;
  margin-top: 5px;
`;

const UserInput = styled.input`
  border: none;
  width: 230px;
  outline: none;
  font-size: 12px;
`;

const Title = styled.div`
  width: 100%;
  background-color: white;
  font-size: 20px;
  text-align: center;
  font-weight: 600;
  padding: 8px 0px;
  margin-bottom: 10px;
`;

const SubmitBtn = styled.button`
  margin-top: 8px;
  margin-bottom: 5px;
  padding: 7px;
  width: 100%;
  text-transform: uppercase;
  outline: 0;
  background: ${({ value }) => (value ? "#26428f" : "#BCBCBC")};

  border: 0;
  border-radius: 10px;
  color: #ffffff;
  -webkit-transition: all 0.3 ease;
  transition: all 0.1s ease-out;
  cursor: pointer;
  font-weight: 500;
  font-size: 13px;
  letter-spacing: 0.03em;
`;
const SignUpWrapper = styled.div`
  display: flex;
  justify-content: center;
  height: 100vh;
  align-items: center;
`;
const SignUpContainer = styled.div.attrs({ className: "SignUp" })`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 350px;
  height: 300px;
  background-color: white;
  font-family: "Pretended";
`;

const SignUpForm = styled.div`
  width: 70%;
  margin: 10px auto;
  text-align: center;
  font-style: normal;
  line-height: 19px;
`;

export default Register;
