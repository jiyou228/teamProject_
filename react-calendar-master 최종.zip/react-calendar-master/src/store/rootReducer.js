import { combineReducers } from "redux";
import * as modules from "./modules";

const rootReducer = combineReducers(modules);

export default rootReducer;
